#include "TimeTest.h"
#define size 100000
#define swap(a,b) {a=a+b;b=a-b;a=a-b;}
int num[size+2];
void travelsal(){
	for(int i=0;i<size;i++)
		std::cout<<num[i]<<" ";
}
void createSrand(){
	srand((unsigned)time(NULL)); 
	for(int i = 0;i<size;i++){
		num[i]=rand()%INT_MAX;
	}
}

void inserationSort(){
	for(int i  =1,j;i<size;i++){
		int tmp = num[i];
		for(j=i;j>0&&tmp<num[j-1];j--)
			num[j]=num[j-1];
		num[j]=tmp;
	}
}

void selectionSort(){
	for(int i=0,j,least;i<size-1;i++){
		for(j=i+1,least=i;j<size;j++)
			if(num[j]<num[least])
				least=j;
		swap(num[least],num[i]);
	}
}

void bubbleSort(){
	for(int i=0;i<size-1;i++)
		for(int j=size-1;j>i;--j)
			if(num[j]<num[j-i])
				swap(num[j],num[j-i]);
}

void adjustHeap(int i, int lef) {
    int temp=num[i];
    for(int k=i*2+1; k<lef; k=k*2+1) { 
        if(k+1<lef&&num[k]<num[k+1]) {
            k++;
        }
        if(num[k]>temp) { 
            num[i]=num[k];
            i=k;
        } else {
            break;
        }
    }
    num[i]=temp;
}
void heapSort(){
	int a=0;
    for(int i = size /2-1; i>=0; i--) {
        adjustHeap(i,size);
    }
    for(int j=size-1; j>0; j--) {
        swap(num[a],num[j]);
        adjustHeap(a, j);
    }
}

void quickSort(int l,int r) {
    if(l>=r)
        return;
    int i = l;
    int j = r;
    int key = num[l];
    while(i<j) {
        while(i<j &&num[j]>=key)
            j--;
        if(i<j) {
           num[i] = num[j];
            i++;
        }
        while(i<j && num[i]<key)
            i++;
        if(i<j) {
            num[j] = num[i];
            j--;
        }
    }
    num[i] = key;
    quickSort(l, i-1);
    quickSort(i+1, r);
}
void quickSort(){
	quickSort(0,size);
}
void merge(int arr[],int l,int mid,int r)
{
    int *aux=new int[r-l+1];//����һ���µ����飬��ԭ����ӳ���ȥ 
    for(int m=l;m<=r;m++)
    {
        aux[m-l]=arr[m];
    }
    
    int i=l,j=mid+1;//i��j�ֱ�ָ�����������鿪ͷ����
    
    for(int k=l;k<=r;k++)
    {
        if(i>mid)
        {
            arr[k]=aux[j-l];
            j++;
        }
        else if(j>r)
        {
            arr[k]=aux[i-l];
            i++;
        }
                else if(aux[i-l]<aux[j-l])
                {
                    arr[k]=aux[i-l];
                    i++;    
                }
                else
                {
                    arr[k]=aux[j-l];
                    j++;
                }
    } 
} 
void merge_sort(int arr[],int l,int r)
{
    if(l >=r)
        return ;
    int mid=(l+r)/2; 
    merge_sort(arr,l,mid);
    merge_sort(arr,mid+1,r);
    merge(arr,l,mid,r);
}

void mergeSort()
{
    merge_sort(num,0,size-1);    
} 

TimeTEST(BaseCostTest)
{
	createSrand();
    std::cout << "��������������Ļ�����ʱ" << std::endl;
}

TimeTEST(test_1)
{
	createSrand();
    std::cout << "inserationSort() test ..." << std::endl;
	inserationSort();
}

TimeTEST(test_2)
{
	createSrand();
    std::cout << "selectionSort() test ..." << std::endl;
	selectionSort();
}

TimeTEST(test_3)
{
	createSrand();
    std::cout << "bubbleSort() test ..." << std::endl;
	bubbleSort();
}

TimeTEST(test_4)
{
	createSrand();
    std::cout << "heapSort() test ..." << std::endl;
	heapSort();
	//travelsal();
}
TimeTEST(test_5)
{
	createSrand();
    std::cout << "quickSort() test ..." << std::endl;
	quickSort();
	//travelsal();
}

TimeTEST(test_6)
{
	createSrand();
    std::cout << "mergeSort() test ..." << std::endl;
	mergeSort();
	//travelsal();
}


