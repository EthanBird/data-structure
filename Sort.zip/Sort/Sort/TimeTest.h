#pragma once
#include <iostream>
#include <queue>
#include <chrono>
#define SIZE 50002
using namespace std::chrono;

namespace _TimeTest
{
//A Base Timer
class TimerBase
{
public:
    TimerBase() : m_start(system_clock::time_point::min()) {}

    void Clear()
    {
        m_start = system_clock::time_point::min();
    }

    void Start()
    {
        m_start = system_clock::now();
    }

    bool IsStarted() const
    {
        return (m_start.time_since_epoch() != system_clock::duration(0));
    }

    unsigned long GetMs()
    {
        if (IsStarted())
        {
            system_clock::duration diff;
            diff = system_clock::now() - m_start;
            return (unsigned)(duration_cast<milliseconds>(diff).count());
        }
        return 0;
    }
private:
    system_clock::time_point m_start;
};

class TimeBaseTest
{
public:
    virtual void run()=0;
    virtual ~TimeBaseTest(){}
    static TimerBase timer;
};

TimerBase TimeBaseTest::timer;
std::queue<TimeBaseTest *> tests;
}

#define TEST_CLASS(test_case_name) \
class TEST_CLASS_##test_case_name : public _TimeTest::TimeBaseTest {\
public:\
    TEST_CLASS_##test_case_name()\
    {\
        _TimeTest::tests.push(this);\
    }\
    void run();\
};\

/* TEST_CLASS_INSTANCE
 * 1.delcare the test class TEST_CLASS_test_case_name
 * 2.get a instance of the class
 * 3.define the run() for the class
 * */

#define TEST_CLASS_INSTANCE(test_case_name) \
    TEST_CLASS(test_case_name);\
    auto test_case_name##_instance = new TEST_CLASS_##test_case_name;\
    void TEST_CLASS_##test_case_name::run()

#define TimeTEST(test_case_name) TEST_CLASS_INSTANCE(test_case_name)

#define RunAllTimeTest(); \
    while(!_TimeTest::tests.empty())\
    {\
        auto i = _TimeTest::tests.front();\
        _TimeTest::tests.pop();\
        std::cout << "[    RUN    ]" << std::endl;\
        i->timer.Start();\
        i->run();\
        std::cout << "[    FINISH,USE TIME : "<< i->timer.GetMs() <<"ms]" << std::endl;\
        i->timer.Clear();\
        delete i;\
    }\


int main()
{
    RunAllTimeTest();
	system("pause");
    return 0;
}