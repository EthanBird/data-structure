#include <iostream>
#include <cstring>
#include <vector>
#include <algorithm>
#include <memory>
#include <limits>
#include <unordered_map>
#include "graph.h"
using std::string;
const double INF = std::numeric_limits<double>::infinity();
void dijkstra(Graph<string,double> g,unsigned int source,unsigned target,
			  std::unordered_map<unsigned int ,double> &return_dist,
			  std::unordered_map<unsigned int ,int> &return_prev)
{
	// Check that source and target are in graph
    if (g.nodes.find(source) == g.nodes.end() || g.nodes.find(target) == g.nodes.end())
    {
        cout << "Source and/or target nodes not in graph." << endl;
        return;
    }

    std::vector<unsigned int> list; // list of nodes to process
    std::unordered_map<unsigned int, double> dist; // id, distance
    std::unordered_map<unsigned int, int> prev; // id, previous

    // Initialize
    for(auto n : g.nodes)
    {
        list.push_back(n.first);
        dist.emplace(n.first, INF);
        prev.emplace(n.first, -1); // -1: no prev node
    }

    dist.at(source) = 0;

    while(!list.empty())
    {
        // Select node with smallest distance
        unsigned int node = list.at(0);
        for(auto id : list)
            if(dist.at(id) < dist.at(node))
                node = id;

        
        if(node == target)
            break;

        // Remove node from list
        list.erase(std::remove(list.begin(), list.end(), node), list.end());

        // Check if target is unreachable
        if(dist.at(node) >= INF)
            break;

        // For each neighbour of node
        for(auto e : g.nodes.at(node)->edges_out)
        {
            auto neighbour = e->to->id;
            double new_dist = dist.at(node) + e->data;
            if(new_dist < dist.at(neighbour))
            {
                dist.at(neighbour) = new_dist;
                prev.at(neighbour) = node;
                // decrease-key v in Q; // Reorder v in the Queue (that is, heapify-down)
            }

        }
    }

    return_dist = dist;
    return_prev = prev;
}

int main(){
	string city_name[12]={"����","�ӻ�","����","����","˳��","�麣",
		"��ɽ","��ݸ","�Ϻ�","����ˮ��","����","�Ƹ�"};
	Graph<string,double> my_graph;
	for(int id=0;id<12;id++)
		my_graph.add_node(id,city_name[id]);
	my_graph.add_edge(0,1,24);
    my_graph.add_edge(0,10,52);
    my_graph.add_edge(1,2,57);
    my_graph.add_edge(1,10,180);
    my_graph.add_edge(2,3,36);
    my_graph.add_edge(3,8,44);
    my_graph.add_edge(4,9,111);
	my_graph.add_edge(5,0,74);
    my_graph.add_edge(6,11,62);
    my_graph.add_edge(6,1,52);
    my_graph.add_edge(7,2,106);
	my_graph.add_edge(7,11,98);
    my_graph.add_edge(8,4,93);
    my_graph.add_edge(9,7,49);
    my_graph.add_edge(11,5,101);
	my_graph.add_edge(10,0,273);
	my_graph.add_edge(10,2,273);
    my_graph.add_edge(6,0,149);
    my_graph.add_edge(11,0,121);

	cout<<"My graph"<<endl;
	cout<<my_graph<<endl;
	system("pause");

	// Run Dijkstra
    std::unordered_map<unsigned int, double> dist; // id, distance
    std::unordered_map<unsigned int, int> prev; // id, previous
    unsigned int source = 0;
    unsigned int target = 11;
    dijkstra(my_graph, source, target, dist, prev);

    cout << "Prev result" << endl;
    for(auto n : prev)
        cout << n.first << ", " << n.second << endl;

    //Construct path  
    std::vector<unsigned int> path;
    unsigned int u = target;
    while (prev.at(u) >= 0)
    {
        path.push_back(u);
        u = prev.at(u);
    }
	 // Add source (will be target if no feasible path is found)
    path.push_back(u);
	/*
	cout << "Path " << endl;
    for(auto n : path)
        cout << n << endl;
	*/
    // Print results
    cout << "The shortest path from " << source << " to " << target << " is:" << endl;
    for(int i = path.size()-1; i>=0; i--)
    {
        unsigned int n = path.at(i);
        cout << n << " (" << dist.at(n) << ")";
        if(i > 0)
            cout << " => ";
    }
    cout << endl;
	system("pause");
}