#include "Godel.h"


Godel::Godel(void)
{
	GeneratePrime();
	Initial();
}
//����������
void Godel::GeneratePrime(){
	prime.push_back(2);
    for (int i, n = 3, tmp = 3; n<10000; n += 2) {
        i = i = sqrt(n);
        if (i % 2 == 0)i -= 1;
        for (; i > 2; i -= 2)
            if (n%i == 0)break;
        if (i <= 2) {
			prime.push_back(n);
            tmp = n;
        }
    }
	//cout<<prime.size();//10000������1229������
}
void Godel::Initial(){
	//TODO
	BigInteger a=123;
	cout<<"����123^45..."<<endl<<"123^45="<<pow(123,45)<<endl;
	string expression;
	cout<<"����Godel����ʽ��\n";
	cin>>expression;
	GN(expression);
}
//����Godel����ʽ
void Godel::GN(string expression){
	int head=0,tail=expression.length();
	BigInteger result = 1;
	for(head;head<tail;head++){
		int cutlen=1;
		if(expression[head]=='x'||expression[head]=='X'){
			cutlen=2;
		}
		result*=pow(prime[head],GNS(expression.substr(head,cutlen)));
		head+=cutlen==2?1:0;
	}
	
	cout<<"����GodelֵΪ��";
	cout<<result<<endl;
}
int Godel::GNS(string c){
	int i=0;
	int t=0;
	switch (c[0])
	{
	case '=':i=1;break;
	case '+':i=2;break;
	case '*':i=3;break;
	case '-':i=4;break;
	case '/':i=5;break;
	case '(':i=6;break;
	case ')':i=7;break;
	case '^':i=8;break;
	case '0':i=9;break;
	case 'S':i=10;break;//���������δ���
	case 'x':t = c[1]-'0';i=11+2*t;break;
	case 'X':t = c[1]-'0';i=12+2*t;break;
	default:
		break;
	}
	return i;
}
BigInteger Godel::pow(int b, int n)
{
	const int MAXSIZE = 200000;
	time_t start, end;//��ʱ
	int *a, i, j;
	start = time(NULL);
	a = (int *)malloc(sizeof(int)* MAXSIZE);
	for (i = 0; i<MAXSIZE; i++)
		a[i] = 0;
	a[MAXSIZE-1] = 1;
	for (i = 1; i<n + 1; i++)
	{
		for (j = 0; j<MAXSIZE; j++)
 
			a[j] *= b;
		for (j = MAXSIZE-1; j >= 0; j--)
		if (a[j] >= 10)
		{
			a[j - 1] += a[j] / 10;
			a[j] %= 10;
		}
	}
	end = time(NULL);
	for (i = 0; a[i] == 0; i++);
	string str;
	for (i; i<MAXSIZE; i++)
		str+=a[i]+'0';
	free(a);
	BigInteger big=str.c_str();
	//cout << endl;
	//cout<<big << "�����ʱ��" << difftime(end, start) <<"ms"<< endl;
	return big;
}
Godel::~Godel(void)
{
}
