#ifndef TTest
#define TTest

#include "TimeTest.h"
#include "Godel.h"
TimeTEST(test_1)
{
    int a = 2;
    std::cout << "this is test_1" << std::endl;
    std::cout << a << std::endl;
}

TimeTEST(test_2)
{
    std::cout << "this is test_2" << std::endl;
}

TimeTEST(BigIntegerTest){
	std::cout << "this is GodelTest" << std::endl;
	Godel tmp;
	tmp.Initial();
}

#endif //TTest