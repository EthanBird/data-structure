#include"Godel.h"
int main(){
	Godel tmp;
	system("pause");
}