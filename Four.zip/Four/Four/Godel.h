#pragma once
#include<string>
#include"BigInteger.h"
class Godel
{
public:
	Godel(void);
	~Godel(void);
	void Initial();
	void GN(string str);
	int GNS(string c);
	//a^x
	BigInteger pow(int b,int x);
private:
	void GeneratePrime();
	vector<int> prime;
};

